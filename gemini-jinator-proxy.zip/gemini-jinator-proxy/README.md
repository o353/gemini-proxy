# Gemini Janitor Proxy

A small FastAPI service that accepts OpenAI-compatible chat-completion requests and forwards them to Google's Gemini API. It enforces `thinking_level="high"` and enables Google Search grounding on every generation request.

## Endpoints

- `GET /` — health check; no key required.
- `GET /v1/models` — returns the configured Gemini model; requires the proxy bearer key.
- `POST /v1/chat/completions` — OpenAI-compatible chat request; requires the proxy bearer key.

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `GEMINI_API_KEY` | Yes | API key from Google AI Studio. Keep it secret. |
| `PROXY_API_KEY` | Yes | A separate, long random secret used by Janitor AI to access this proxy. |
| `GEMINI_MODEL` | No | Defaults to `gemini-3-flash-preview`. |

Never put either secret in source code or commit it to GitHub.

## Deploy on Render

1. Push these files to a GitHub repository.
2. In Render, choose **New + → Blueprint** and select the repository, or create a **Web Service** from it.
3. Add `GEMINI_API_KEY` and `PROXY_API_KEY` as secret environment variables. Keep `GEMINI_MODEL` as `gemini-3-flash-preview` unless you intentionally use another supported model.
4. If creating a Web Service manually, use:
   - Build command: `pip install -r requirements.txt`
   - Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. After deployment, open `https://YOUR-SERVICE.onrender.com/`; it should return JSON with `"status":"ok"`.

## Janitor AI connection

- **Base URL:** `https://YOUR-SERVICE.onrender.com/v1`
- **API key:** the value of `PROXY_API_KEY` (not the Google Gemini key)
- **Model:** `gemini-3-flash-preview` (the proxy uses `GEMINI_MODEL` configured on the server)

Use the `/v1` suffix in the Base URL. Do not share your keys in screenshots or messages.

## Compatibility notes

- Text messages and system/developer instructions are converted to Gemini contents.
- This is a text-oriented compatibility layer; it does not implement arbitrary OpenAI tool/function calling or full multimodal image handling.
- When `stream=true`, it returns Server-Sent Events in OpenAI chunk format, but the Gemini response is generated fully before those chunks are sent. This is compatibility streaming, not live token streaming.
- Google Search grounding depends on the selected Gemini model, API availability, and Google's account/usage policies.
